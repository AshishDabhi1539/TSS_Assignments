package com.tss.employee_service.dto;

import lombok.Data;

@Data
public class EmployeeRequestDto {
    private String name;
    private double salary;
    private long deptId;
}
