package com.tss.department_service.dto;

import lombok.Data;

@Data
public class DepartmentRequestDto {
    private String departmentName;
    private String location;
}
